
import json, uuid, hashlib, random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional, Callable
from enum import Enum

# ============================================================
# Minimal universal vocabulary (compressed / single-file)
#   Vessel / World / Action / Rules / Adapter / ScriptureSolver
# ============================================================

# --- Modes / Actions (tiny) ---
class Mode(str, Enum):
    R = "R"  # RESTORE
    N = "N"  # NORMAL

class ActionType(str, Enum):
    O = "O"  # OPEN  (add vessel)
    B = "B"  # BUILD (add unit to vessel)
    R = "R"  # RESERVE (storehouse)
    I = "I"  # INNOV (tests pool)
    H = "H"  # HOLD

# Road labels (UI only, not ontology)
ROAD_BOOTSTRAP = "BS"
ROAD_RESTORE   = "RS"
ROAD_BUILD     = "BD"
ROAD_ALLOCATE  = "AL"
ROAD_HOLD      = "HL"

@dataclass(frozen=True)
class Action:
    k: ActionType
    i: Optional[int] = None  # vessel index
    amt: float = 0.0
    tg: str = ""             # tag

# --- ProblemSeed (problem parameters) ---
@dataclass(frozen=True)
class ProblemSeed:
    idn: Dict[str, Any] = field(default_factory=dict)   # identity: name/jurisdiction/translation_pack
    ph: str = "Setup"                                  # Setup|Positioning|Conversion
    st: Dict[str, Any] = field(default_factory=dict)    # state snapshot (domain-specific)
    fl: Dict[str, float] = field(default_factory=dict)  # floors e.g. {"cash":..., "reserve":..., "maturity":...}
    cx: Dict[str, Any] = field(default_factory=dict)    # constraints e.g. {"quarantine":True,"mincap":3,"span":12}
    oc: Dict[str, Any] = field(default_factory=dict)    # outcomes/measures (domain-specific)

# --- Scripture solution primitives (no new nouns) ---
@dataclass(frozen=True)
class ScriptureAnchor:
    # Shorthand reference id:
    #   e.g. "PRV4:23" or "EXO18:17-23" or "JHN15:2"
    # Optional word-span shorthand:
    #   e.g. "w1-7" meaning words 1..7 of the verse (requires translation pack text to be exact)
    rid: str
    pr: str        # principle (short)
    sm: str        # summary (very short)
    w: Optional[str] = None

@dataclass(frozen=True)
class ScriptureSolution:
    d: List[str]                      # domains (1-3)
    a: List[ScriptureAnchor]          # anchors
    x: List[str]                      # directives (codes)

# --- Ledger (short keys) ---
def _cj(o: Any) -> str:
    return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

def _h(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def _uid() -> str:
    return str(uuid.uuid4())

@dataclass
class Ledger:
    v: str = "PCK_PE_v3"
    e: List[Dict[str, Any]] = field(default_factory=list)

    def emit(self, pt: str, p: Dict[str, Any]) -> None:
        pkt = {"pt": pt, "id": _uid(), "v": self.v, **p}
        pkt["cs"] = _h(_cj({k: v for k, v in pkt.items() if k != "cs"}))
        self.e.append(pkt)

    def jsonl(self) -> str:
        return "\n".join(_cj(x) for x in self.e)

# --- Roles (kept, but compressed) ---
@dataclass(frozen=True)
class RoleHandoff:
    d: str = "Guide"    # decided_by
    r: str = "Scribe"   # recorded_by
    x: str = "Steward"  # executed_by

# --- Rules / Quarantine registries (dict-based) ---
TestFn  = Callable[['World'], Tuple[bool, Dict[str, bool]]]
RestFn  = Callable[['World'], Optional[Action]]
GateFn  = Callable[['World', Action], Dict[str, bool]]

@dataclass
class SeedRules:
    Y: int = 40
    rng: int = 7
    Q: int = 2                 # quarantine: pass threshold among gate tests (count of True)
    IV: int = 3                # init vessels
    SP: int = 12               # span to maturity (12:1)
    FF: float = 0.10           # firstfruits rate
    IN: float = 0.10           # innovation rate

    pr: str = "cash"           # primary resource key
    fl: Dict[str, float] = field(default_factory=lambda: {"cash": 2_000_000})
    shf: float = 5_000_000     # storehouse floor
    mc: int = 3                # min mature vessels

    # Data-driven restore priority order
    rp: List[str] = field(default_factory=lambda: ["Liquidity", "MinCap", "Storehouse"])

    # Registries are assigned at init if empty
    rules: Dict[str, Dict[str, Any]] = field(default_factory=dict)      # name -> {test, restore}
    gates: Dict[str, Dict[str, Any]] = field(default_factory=dict)      # name -> {test}

# --- Adapter interface (domain mapping) ---
class Adapter:
    def cost(self, w: 'World', a: Action) -> float: raise NotImplementedError
    def dyn(self,  w: 'World') -> Dict[str, Any]: raise NotImplementedError
    def apply(self,w: 'World', a: Action) -> None: raise NotImplementedError
    def msr(self,  w: 'World') -> Dict[str, Any]: return {}  # optional measures

# EconDev pressure adapter (still just an adapter)
class EconDevAdapter(Adapter):
    def __init__(self, seed_in: float, cost_unit: float, surp_unit: float, shock_n: int, shock_i: float, fail: float, rng: int):
        self.SI = seed_in
        self.CU = cost_unit
        self.SU = surp_unit
        self.SN = max(1, shock_n)
        self.SI2 = shock_i
        self.FA = fail
        self.r = random.Random(rng)

    def cost(self, w, a: Action) -> float:
        if a.k == ActionType.B: return self.CU
        if a.k in (ActionType.R, ActionType.I): return a.amt
        return 0.0

    def dyn(self, w) -> Dict[str, Any]:
        sk_in = (self.r.random() < 1 / self.SN)
        sk_su = (self.r.random() < 1 / self.SN)

        inflow = self.SI * (1 - self.SI2) if sk_in else self.SI
        w.rs[w.ru.pr] += inflow

        surplus = w.ut * self.SU
        surplus = surplus * (1 - self.SI2) if sk_su else surplus
        w.rs[w.ru.pr] += surplus

        vb = len(w.v)
        pruned = False
        if self.FA and w.v:
            w.v = [vv for vv in w.v if self.r.random() > self.FA]
            if not w.v:
                w.bs(1)
            pruned = (len(w.v) != vb)

        return {"i": int(sk_in), "s": int(sk_su), "in": inflow, "su": surplus, "p": int(pruned), "vb": vb, "va": len(w.v)}

    def apply(self, w, a: Action) -> None:
        if a.k == ActionType.O:
            w.ov()
        elif a.k == ActionType.B and a.i is not None:
            w.bu(a.i)
            w.rs[w.ru.pr] -= self.CU
        elif a.k == ActionType.R:
            x = min(a.amt, w.hr())
            w.rs[w.ru.pr] -= x; w.sh += x
        elif a.k == ActionType.I:
            x = min(a.amt, w.hr())
            w.rs[w.ru.pr] -= x; w.tp += x

    def msr(self, w) -> Dict[str, Any]:
        return {"ut": w.ut, "v": len(w.v), "cn": w.cn, "on": w.on}

# --- Vessel / World (status collapsed to mature bool) ---
@dataclass
class Vessel:
    id: int
    u: int = 0
    m: bool = False

    def up(self, sp: int) -> None:
        if (not self.m) and self.u >= sp:
            self.m = True

@dataclass
class World:
    ru: SeedRules
    ad: Adapter
    ps: Optional[ProblemSeed] = None

    rs: Dict[str, float] = field(default_factory=dict)  # resources
    sh: float = 0.0                                     # storehouse
    tp: float = 0.0                                     # tests pool
    v: List[Vessel] = field(default_factory=list)

    m: Mode = Mode.R
    t: int = 0
    ne: int = 0

    @property
    def ut(self) -> int:  # units_total
        return sum(x.u for x in self.v)

    @property
    def cn(self) -> int:  # cap_n
        return sum(1 for x in self.v if x.m)

    @property
    def on(self) -> int:  # open_n
        return sum(1 for x in self.v if not x.m)

    def hr(self) -> float:  # headroom above liquidity floor
        return max(0.0, self.rs[self.ru.pr] - self.ru.fl[self.ru.pr])

    def bs(self, n: int) -> None:  # bootstrap vessels
        s = len(self.v)
        for i in range(n):
            self.v.append(Vessel(id=s + i + 1))

    def ov(self) -> None:  # open vessel
        self.v.append(Vessel(id=len(self.v) + 1))

    def bu(self, i: int) -> None:  # build unit
        if i < 0 or i >= len(self.v): return
        vv = self.v[i]
        vv.u += 1
        vv.up(self.ru.SP)

    def pk(self) -> Optional[int]:  # pick most-filled open vessel
        c = [(i, vv.u) for i, vv in enumerate(self.v) if not vv.m]
        c.sort(key=lambda x: x[1], reverse=True)
        return c[0][0] if c else None

# --- ScriptureSolver (PolicyCompiler) ---
class ScriptureSolver:
    """
    Emits:
      domains (1-3), anchors (rid/pr/sm/w), directives (codes)
    No verse text embedded (copyright). Use refs + ultra-short summaries.
    Word-span shorthand 'w#-#' supported if your translation pack supplies tokenization.
    """
    def __init__(self, tr: str = "NIV"):
        self.tr = tr
        self.dom = {
            "SF": {  # Stability / Foundation
                "a": [
                    ScriptureAnchor(rid="PRV4:23", pr="Guard gates", sm="Guard inputs; flows follow.", w="w1-6"),
                ],
                "x": ["FLOOR_FIRST", "QUARANTINE_UNKNOWN"]
            },
            "GD": {  # Governance / Delegation
                "a": [
                    ScriptureAnchor(rid="EXO18:17-23", pr="Delegation", sm="Share load; appoint tens.", w=None),
                ],
                "x": ["SPAN_LIMIT"]
            },
            "PS": {  # Provision / Storehouse
                "a": [
                    ScriptureAnchor(rid="GEN41:34-36", pr="Storehouse", sm="Store in plenty for famine.", w=None),
                ],
                "x": ["FIRSTFRUITS"]
            },
            "GF": {  # Growth / Fruit / Pruning
                "a": [
                    ScriptureAnchor(rid="JHN15:2", pr="Prune", sm="Cut/prune to increase fruit.", w="w1-8"),
                ],
                "x": ["PRUNE"]
            },
        }

    def cls(self, ps: ProblemSeed, w: World) -> List[str]:
        d: List[str] = []

        # Phase bias
        if ps.ph == "Setup":
            d.append("SF")
            d.append("PS")

        # Floor / reserve bias
        reserve_floor = ps.fl.get("reserve", w.ru.shf)
        if w.sh < reserve_floor:
            d.append("PS")

        # Formation bias
        mincap = int(ps.cx.get("mincap", w.ru.mc))
        if w.cn < mincap:
            d.append("GD")

        # Restore bias
        if w.m == Mode.R:
            d.append("SF")

        # Prune bias (blocks / churn)
        if w.ne > 0:
            d.append("GF")

        # Dedup, keep 1-3
        out = []
        for x in d:
            if x not in out:
                out.append(x)
        return out[:3]

    def solve(self, ps: ProblemSeed, w: World) -> ScriptureSolution:
        d = self.cls(ps, w)
        anchors: List[ScriptureAnchor] = []
        directives: List[str] = []
        for k in d:
            node = self.dom.get(k)
            if not node: continue
            anchors.extend(node["a"])
            directives.extend(node["x"])
        # dedup directives
        dx = []
        for x in directives:
            if x not in dx:
                dx.append(x)
        return ScriptureSolution(d=d, a=anchors, x=dx)

# --- Kernel ---
class Kernel:
    def __init__(self, ru: SeedRules, ad: Adapter, ps: Optional[ProblemSeed] = None, lg: Optional[Ledger] = None, rh: Optional[RoleHandoff] = None):
        self.ru = ru
        self.ad = ad
        self.ps = ps
        self.ss = ScriptureSolver(tr=(ps.idn.get("translation_pack") if ps else "NIV")) if ps else None
        self.lg = lg
        self.rh = rh or RoleHandoff()

        if not self.ru.rules:
            self.ru.rules = self._default_rules()
        if not self.ru.gates:
            self.ru.gates = self._default_gates()

    # ---- default rule registries (short + universal) ----
    def _default_rules(self) -> Dict[str, Dict[str, Any]]:
        ru = self.ru
        def t_liq(w: World): 
            ok = w.rs[ru.pr] >= ru.fl[ru.pr]
            return ok, {"L": ok}
        def r_liq(w: World): 
            return None

        def t_sh(w: World):
            ok = w.sh >= ru.shf
            return ok, {"S": ok}
        def r_sh(w: World):
            hr = w.hr()
            return Action(ActionType.R, amt=min(500_000, hr), tg="rs_sh") if hr > 0 else None

        def t_mc(w: World):
            ok = w.cn >= ru.mc
            return ok, {"M": ok}
        def r_mc(w: World):
            idx = w.pk()
            bc = w.ad.cost(w, Action(ActionType.B))
            return Action(ActionType.B, i=idx, tg="rs_mc") if (idx is not None and w.hr() >= bc) else None

        return {
            "Liquidity":  {"t": t_liq, "r": r_liq},
            "Storehouse": {"t": t_sh,  "r": r_sh},
            "MinCap":     {"t": t_mc,  "r": r_mc},
        }

    def _default_gates(self) -> Dict[str, Dict[str, Any]]:
        ru = self.ru
        def g_floor(w: World, a: Action) -> Dict[str, bool]:
            spend = w.ad.cost(w, a)
            return {"L": (w.rs[ru.pr] - spend) >= ru.fl[ru.pr]}
        def g_no_open_restore(w: World, a: Action) -> Dict[str, bool]:
            return {"O": not (w.m == Mode.R and a.k == ActionType.O)}
        def g_cap(w: World, a: Action) -> Dict[str, bool]:
            return {"C": True}
        return {
            "GateFloor": {"t": g_floor},
            "GateOpen":  {"t": g_no_open_restore},
            "GateCap":   {"t": g_cap},
        }

    def _mode(self, w: World) -> Tuple[Mode, Dict[str, int]]:
        # returns mode + compact floor report map
        failed = False
        fr: Dict[str, int] = {}
        for name, node in self.ru.rules.items():
            ok, rep = node["t"](w)
            fr[name[:2]] = int(ok)  # super short key from name
            if not ok:
                failed = True
        return (Mode.R if failed else Mode.N), fr

    def _admit(self, w: World, a: Action) -> Tuple[bool, Dict[str, int]]:
        # gate tests: count of True across all gate booleans
        gr: Dict[str, int] = {}
        trues = 0
        for name, node in self.ru.gates.items():
            rep = node["t"](w, a)
            # each rep is small bool dict; compress to 0/1 with combined AND
            ok = all(rep.values()) if rep else True
            gr[name[-2:]] = int(ok)  # last 2 letters as tiny id
            trues += 1 if ok else 0
        ok = trues >= self.ru.Q
        if not ok:
            w.ne += 1
        return ok, gr

    def _route_default(self, w: World) -> Tuple[str, Action]:
        # BOOTSTRAP
        if len(w.v) < self.ru.IV:
            return ROAD_BOOTSTRAP, Action(ActionType.O, tg="bs")

        # mode
        w.m, fr = self._mode(w)

        # RESTORE: data-driven priority order
        if w.m == Mode.R:
            for rn in self.ru.rp:
                node = self.ru.rules.get(rn)
                if not node: 
                    continue
                ok, _ = node["t"](w)
                if ok:
                    continue
                act = node["r"](w)
                if act:
                    return ROAD_RESTORE, act
            return ROAD_RESTORE, Action(ActionType.H, tg="rs_h")

        # NORMAL: build if possible
        idx = w.pk()
        bc = self.ad.cost(w, Action(ActionType.B))
        if idx is not None and w.hr() >= bc:
            return ROAD_BUILD, Action(ActionType.B, i=idx, tg="bd")

        # allocate if headroom
        hr = w.hr()
        if hr > 0:
            if w.sh < self.ru.shf:
                return ROAD_ALLOCATE, Action(ActionType.R, amt=hr * self.ru.FF, tg="ff")
            return ROAD_ALLOCATE, Action(ActionType.I, amt=hr * self.ru.IN, tg="in")

        return ROAD_HOLD, Action(ActionType.H, tg="hl")

    def _route_scripture_bias(self, w: World, road: str, act: Action, sol: Optional[ScriptureSolution]) -> Tuple[str, Action]:
        # Scripture biases routing, never violates floors/gates.
        if not sol:
            return road, act

        # PRIORITY BIASES:
        # - FLOOR_FIRST: if in restore, keep restore (no expansion)
        if "FLOOR_FIRST" in sol.x and w.m == Mode.R:
            # keep restore; let restore rules select specific action
            return ROAD_RESTORE, Action(ActionType.H, tg="sf_floor")

        # - FIRSTFRUITS: if headroom exists and storehouse below floor, reserve first
        if "FIRSTFRUITS" in sol.x:
            hr = w.hr()
            if hr > 0 and w.sh < self.ru.shf:
                return ROAD_ALLOCATE, Action(ActionType.R, amt=hr * self.ru.FF, tg="sf_ff")

        # Other directives (SPAN_LIMIT, PRUNE) are enforcement posture and/or adapter-level ops
        return road, act

    def tick(self, w: World) -> None:
        # 1) dynamics
        sk = self.ad.dyn(w)

        # 2) default route
        road, act = self._route_default(w)

        # 3) scripture solve + bias
        sol = self.ss.solve(self.ps, w) if (self.ss and self.ps) else None
        road, act = self._route_scripture_bias(w, road, act, sol)

        # 4) admit + apply
        gok, gr = self._admit(w, act)
        if gok:
            self.ad.apply(w, act)

        # 5) emit compact packet
        if self.lg:
            # Extremely short keys:
            # t=time, m=mode, r=road, a=action, tg=tag
            # c=primary resource, sh=storehouse, tp=tests
            # v=vessel count, cn=mature count, on=open count, ut=units total
            # ne=never events, g=gate ok, gt=gate tests, sk=shock
            p = {
                "t": w.t,
                "m": w.m.value,
                "r": road,
                "a": act.k.value,
                "tg": act.tg,
                "c": round(w.rs[self.ru.pr], 2),
                "sh": round(w.sh, 2),
                "tp": round(w.tp, 2),
                "v": len(w.v),
                "cn": w.cn,
                "on": w.on,
                "ut": w.ut,
                "ne": w.ne,
                "g": int(gok),
                "gt": gr,
                "sk": sk,
            }
            if sol:
                # sc: domains + anchors + directives
                p["sc"] = {
                    "d": sol.d,
                    "a": [{"i": a.rid, "p": a.pr, "s": a.sm, "w": a.w} for a in sol.a],
                    "x": sol.x
                }
            self.lg.emit("t", p)

    def run(self, start_mult: float = 2.5) -> World:
        w = World(ru=self.ru, ad=self.ad, ps=self.ps, rs={self.ru.pr: self.ru.fl[self.ru.pr] * float(start_mult)})
        w.bs(self.ru.IV)
        for t in range(1, self.ru.Y + 1):
            w.t = t
            self.tick(w)
        return w

# --- Example main (econdev pressure test) ---
def main():
    ru = SeedRules()
    ps = ProblemSeed(
        idn={"name": "NWGA Industrial Readiness", "jurisdiction": ["Catoosa","Chattooga","Dade","Walker"], "translation_pack": "NIV"},
        ph="Setup",
        st={"resources": {"liquidity": 50_000_000, "trust": 0.6, "capacity": 0.4}},
        fl={"liquidity": 50_000_000, "reserve": 150_000_000, "maturity": 3},
        cx={"quarantine": True, "firstfruits_rate": 0.10, "innov_rate": 0.10, "span": 12, "mincap": 3, "never_spend_below_floor": True},
        oc={}
    )

    ad = EconDevAdapter(
        seed_in=2_000_000,
        cost_unit=750_000,
        surp_unit=120_000,
        shock_n=5,
        shock_i=0.3,
        fail=0.05,
        rng=ru.rng
    )

    lg = Ledger(v="PCK_PE_v3_econdev")
    k = Kernel(ru=ru, ad=ad, ps=ps, lg=lg)
    final = k.run()

    print("Final:")
    print("ut", final.ut, "v", len(final.v), "c", round(final.rs[ru.pr],2), "sh", round(final.sh,2), "tp", round(final.tp,2), "cn", final.cn)
    print("\nLedger JSONL (first 3 lines):")
    lines = lg.jsonl().splitlines()
    for ln in lines[:3]:
        print(ln)

if __name__ == "__main__":
    main()
