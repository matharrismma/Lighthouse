# Trust Ladder

1. microSD — root authority
2. USB-C known device
3. NFC intent
4. Physical buttons
5. Software only (never sufficient alone)
