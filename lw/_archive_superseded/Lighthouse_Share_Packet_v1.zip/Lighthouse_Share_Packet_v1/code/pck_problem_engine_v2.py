
import json, uuid, hashlib, random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional, Callable
from enum import Enum

# =========================
# UNIVERSAL GRAMMAR (MINIMAL)
# =========================

class Mode(str, Enum):
    RESTORE = "RESTORE"
    NORMAL = "NORMAL"

class ActionType(str, Enum):
    OPEN = "OPEN"        # create a new Vessel (structure)
    BUILD = "BUILD"      # add one unit to a Vessel (capacity/progress)
    RESERVE = "RESERVE"  # storehouse allocation (firstfruits)
    INNOV = "INNOV"      # tests/innovation allocation (pressure)
    HOLD = "HOLD"        # no-op

# Roads are labels for logs/UI only (not a separate ontology)
ROAD_BOOTSTRAP = "BOOTSTRAP"
ROAD_RESTORE   = "RESTORE"
ROAD_BUILD     = "BUILD"
ROAD_ALLOCATE  = "ALLOCATE"
ROAD_HOLD      = "HOLD"

@dataclass(frozen=True)
class Action:
    k: ActionType
    vessel_i: Optional[int] = None
    amt: float = 0.0
    tag: str = ""

@dataclass(frozen=True)
class ProblemSeed:
    """
    Problem is defined by parameters; solution patterns come from Scripture;
    scenario parameters instantiate actions via the Adapter.
    """
    identity: Dict[str, Any] = field(default_factory=dict)
    phase: str = "Setup"  # Setup|Positioning|Conversion
    floors: Dict[str, float] = field(default_factory=dict)        # e.g. {"cash": OPF, "storehouse": RESF, "mincap": 3}
    constraints: Dict[str, Any] = field(default_factory=dict)     # e.g. {"span": 12, "mincap": 3, "firstfruits": .1, "innov": .1}
    state: Dict[str, Any] = field(default_factory=dict)           # optional extra signals for classification
    outcomes: Dict[str, Any] = field(default_factory=dict)        # optional (lead/lag)

@dataclass(frozen=True)
class ScriptureAnchor:
    ref: str
    principle: str
    summary: str  # short summary (avoid embedding copyrighted translations)

@dataclass(frozen=True)
class ScriptureSolution:
    domains: List[str]
    anchors: List[ScriptureAnchor]
    directives: List[Dict[str, str]]  # [{"rule":"FIRSTFRUITS","meaning":"..."}]

# =========================
# LEDGER (PACKETS)
# =========================

def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def uid() -> str:
    return str(uuid.uuid4())

@dataclass
class Ledger:
    kernel_version: str = "PCK_problem_engine_v2"
    events: List[Dict[str, Any]] = field(default_factory=list)

    def emit(self, packet_type: str, payload: Dict[str, Any]) -> None:
        pkt = {"packet_type": packet_type, "packet_id": uid(), "kernel_version": self.kernel_version, **payload}
        pkt["checksum"] = sha256_hex(canonical_json({k: v for k, v in pkt.items() if k != "checksum"}))
        self.events.append(pkt)

    def to_jsonl(self) -> str:
        return "\n".join(canonical_json(e) for e in self.events)

# =========================
# ROLES (UNIVERSAL)
# =========================

@dataclass(frozen=True)
class Role:
    name: str

GUIDE = Role("Guide")
SCRIBE = Role("Scribe")
STEWARD = Role("Steward")

@dataclass(frozen=True)
class RoleHandoff:
    decided_by: Role = GUIDE
    recorded_by: Role = SCRIBE
    executed_by: Role = STEWARD
    note: Optional[str] = None

# =========================
# SCRIPTURE SOLVER (POLICY COMPILER)
# =========================

class ScriptureSolver:
    """
    Classifies the current problem pressure into 1–3 domains,
    then returns directives that bias kernel routing (without new nouns).
    """
    def __init__(self, translation_pack: str = "NIV"):
        self.translation_pack = translation_pack
        self.domains = {
            "Stability / Foundation": {
                "anchors": [ScriptureAnchor("Proverbs 4:23", "Guard inputs; control gates",
                                           "Guard what drives your outputs; protect the system’s heart.")],
                "directives": [
                    {"rule": "FLOOR_FIRST", "meaning": "Stability before expansion"},
                    {"rule": "QUARANTINE_UNKNOWN", "meaning": "Admit only validated work"},
                ],
            },
            "Governance / Delegation": {
                "anchors": [ScriptureAnchor("Exodus 18", "Delegation / span of care",
                                           "Distribute load; appoint capable leaders; reduce overload.")],
                "directives": [{"rule": "SPAN_LIMIT", "meaning": "No vessel exceeds span limit"}],
            },
            "Provision / Storehouse": {
                "anchors": [ScriptureAnchor("Genesis 41", "Storehouse reserves",
                                           "Store during abundance to withstand famine; prevent ruin.")],
                "directives": [{"rule": "FIRSTFRUITS", "meaning": "Reserve allocation (storehouse)"}],
            },
            "Growth / Fruit / Pruning": {
                "anchors": [ScriptureAnchor("John 15:2", "Prune for fruit",
                                           "Cut off fruitless branches; prune fruitful ones to increase yield.")],
                "directives": [{"rule": "PRUNE", "meaning": "Remove fruitless branches when needed"}],
            },
        }

    def classify_domains(self, seed: ProblemSeed, w: "World") -> List[str]:
        domains: List[str] = []

        # Setup pressure usually favors storehouse + stability
        if seed.phase == "Setup":
            domains.append("Provision / Storehouse")

        # Floors pressure
        if w.mode == Mode.RESTORE:
            domains.append("Stability / Foundation")

        # Formation pressure
        mincap = int(seed.constraints.get("mincap", seed.floors.get("mincap", 3) or 3))
        if w.cap_n < mincap:
            domains.append("Governance / Delegation")

        # Repeated blocks = pruning lens
        if w.never_events > 0:
            domains.append("Growth / Fruit / Pruning")

        # Keep 1–3
        out: List[str] = []
        for d in domains:
            if d not in out and d in self.domains:
                out.append(d)
        return out[:3]

    def solve(self, seed: ProblemSeed, w: "World") -> ScriptureSolution:
        ds = self.classify_domains(seed, w)
        anchors: List[ScriptureAnchor] = []
        directives: List[Dict[str, str]] = []
        for d in ds:
            anchors.extend(self.domains[d]["anchors"])
            directives.extend(self.domains[d]["directives"])
        return ScriptureSolution(domains=ds, anchors=anchors, directives=directives)

# =========================
# ADAPTER (DOMAIN MAPPING)
# =========================

class Adapter:
    def cost(self, w: "World", a: Action) -> float: raise NotImplementedError
    def dynamics(self, w: "World") -> Dict[str, Any]: raise NotImplementedError
    def apply(self, w: "World", a: Action) -> None: raise NotImplementedError
    def measures(self, w: "World") -> Dict[str, Any]: raise NotImplementedError

class EconDevAdapter(Adapter):
    """
    Pressure-test adapter: lumpy CAPEX + compounding surplus + shocks + failures.
    """
    def __init__(self, seed_in: float, cost_unit: float, surp_unit: float, shock_n: int, shock_i: float, fail: float, rng: int):
        self.SEED_IN = float(seed_in)
        self.COST = float(cost_unit)
        self.SURP = float(surp_unit)
        self.SHOCKN = max(1, int(shock_n))
        self.SHOCKI = float(shock_i)
        self.FAIL = float(fail)
        self.rng = random.Random(rng)

    def cost(self, w: "World", a: Action) -> float:
        if a.k == ActionType.BUILD: return self.COST
        if a.k in (ActionType.RESERVE, ActionType.INNOV): return float(a.amt)
        return 0.0

    def dynamics(self, w: "World") -> Dict[str, Any]:
        shock_in = (self.rng.random() < 1 / self.SHOCKN)
        shock_sur = (self.rng.random() < 1 / self.SHOCKN)

        inflow = self.SEED_IN * (1 - self.SHOCKI) if shock_in else self.SEED_IN
        w.resources[w.primary] += inflow

        surplus = w.units_total * self.SURP
        surplus *= (1 - self.SHOCKI) if shock_sur else 1.0
        w.resources[w.primary] += surplus

        before = len(w.vessels)
        pruned = False
        if self.FAIL and w.vessels:
            w.vessels = [v for v in w.vessels if self.rng.random() > self.FAIL]
            if not w.vessels:
                w.bootstrap_vessels(1)
            pruned = (len(w.vessels) != before)

        return {
            "shock_inflow": shock_in, "shock_surplus": shock_sur,
            "inflow": inflow, "surplus": surplus,
            "pruned": pruned, "vessels_before": before, "vessels_after": len(w.vessels),
        }

    def apply(self, w: "World", a: Action) -> None:
        if a.k == ActionType.OPEN:
            w.open_vessel()
        elif a.k == ActionType.BUILD and a.vessel_i is not None:
            w.build_unit(a.vessel_i)
            w.resources[w.primary] -= self.COST
        elif a.k == ActionType.RESERVE:
            x = min(float(a.amt), w.headroom())
            w.resources[w.primary] -= x
            w.storehouse += x
        elif a.k == ActionType.INNOV:
            x = min(float(a.amt), w.headroom())
            w.resources[w.primary] -= x
            w.tests_pool += x
        # HOLD -> no-op

    def measures(self, w: "World") -> Dict[str, Any]:
        return {"units_total": w.units_total, "vessels": len(w.vessels), "cap_n": w.cap_n, "open_n": w.open_n}

# =========================
# WORLD + VESSEL
# =========================

@dataclass
class Vessel:
    id: int
    units: int = 0
    mature: bool = False  # (Action 1) collapse Status -> boolean

    def update(self, span: int) -> None:
        if (not self.mature) and self.units >= span:
            self.mature = True

@dataclass
class SeedRules:
    # cycles / gates
    Y: int = 40
    rng: int = 7
    Q: int = 2  # quarantine threshold among gate tests

    # structure
    INIT_VESSELS: int = 3
    SPAN: int = 12      # maturity units per vessel
    mincap: int = 3     # minimum mature vessels

    # resource naming + floors
    primary_resource: str = "cash"
    floors: Dict[str, float] = field(default_factory=lambda: {"cash": 2_000_000})
    storehouse_floor: float = 5_000_000

    # allocations
    FIRSTFRUIT_RATE: float = 0.10
    INNOV_RATE: float = 0.10

    # (Action 3 & 4) rule registries + priorities (data-driven)
    rule_priority: List[str] = field(default_factory=lambda: ["Liquidity Floor", "Min Capacity", "Storehouse Floor"])
    rules: Dict[str, Dict[str, Any]] = field(default_factory=dict)           # floor rules
    quarantine: Dict[str, Dict[str, Any]] = field(default_factory=dict)      # gate rules

@dataclass
class World:
    rules: SeedRules
    adapter: Adapter
    resources: Dict[str, float] = field(default_factory=dict)
    storehouse: float = 0.0
    tests_pool: float = 0.0
    vessels: List[Vessel] = field(default_factory=list)

    mode: Mode = Mode.RESTORE
    t: int = 0
    never_events: int = 0

    @property
    def primary(self) -> str:
        return self.rules.primary_resource

    @property
    def units_total(self) -> int:
        return sum(v.units for v in self.vessels)

    @property
    def cap_n(self) -> int:
        return sum(1 for v in self.vessels if v.mature)

    @property
    def open_n(self) -> int:
        return sum(1 for v in self.vessels if not v.mature)

    def headroom(self) -> float:
        floor = float(self.rules.floors.get(self.primary, 0.0))
        return max(0.0, float(self.resources.get(self.primary, 0.0)) - floor)

    def bootstrap_vessels(self, n: int) -> None:
        start = len(self.vessels)
        for i in range(n):
            self.vessels.append(Vessel(id=start + i + 1))

    def open_vessel(self) -> None:
        self.vessels.append(Vessel(id=len(self.vessels) + 1))

    def build_unit(self, vessel_i: int) -> None:
        if vessel_i < 0 or vessel_i >= len(self.vessels): return
        v = self.vessels[vessel_i]
        v.units += 1
        v.update(self.rules.SPAN)

    def pick_open(self) -> Optional[int]:
        candidates = [(i, v.units) for i, v in enumerate(self.vessels) if not v.mature]
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0] if candidates else None

# =========================
# KERNEL
# =========================

class Kernel:
    def __init__(self, rules: SeedRules, adapter: Adapter, problem_seed: Optional[ProblemSeed] = None,
                 ledger: Optional[Ledger] = None, handoff: Optional[RoleHandoff] = None):
        self.rules = rules
        self.adapter = adapter
        self.problem_seed = problem_seed
        self.ledger = ledger
        self.handoff = handoff or RoleHandoff()
        self.solver = ScriptureSolver(problem_seed.identity.get("translation_pack", "NIV")) if problem_seed else None

        # (Action 3) rule registry is dict-driven; build defaults if missing
        if not self.rules.rules:
            self.rules.rules = self._default_floor_rules()
        if not self.rules.quarantine:
            self.rules.quarantine = self._default_quarantine_rules()

    # --------- Rule registries (dict-based) ---------

    def _default_floor_rules(self) -> Dict[str, Dict[str, Any]]:
        primary = self.rules.primary_resource
        opf = float(self.rules.floors.get(primary, 0.0))
        resf = float(self.rules.storehouse_floor)
        mincap = int(self.rules.mincap)

        def liquidity_test(w: World) -> Tuple[bool, Dict[str, Any]]:
            ok = float(w.resources.get(primary, 0.0)) >= opf
            return ok, {"primary": primary, "need": opf, "have": float(w.resources.get(primary, 0.0))}

        def liquidity_restore(w: World) -> Optional[Action]:
            # liquidity floor is not directly "restored" by action here; it's protected by gates
            return None

        def storehouse_test(w: World) -> Tuple[bool, Dict[str, Any]]:
            ok = float(w.storehouse) >= resf
            return ok, {"need": resf, "have": float(w.storehouse)}

        def storehouse_restore(w: World) -> Optional[Action]:
            hr = w.headroom()
            if hr <= 0: return None
            return Action(ActionType.RESERVE, amt=min(500_000.0, hr), tag="restore-storehouse")

        def mincap_test(w: World) -> Tuple[bool, Dict[str, Any]]:
            ok = int(w.cap_n) >= mincap
            return ok, {"need": mincap, "have": int(w.cap_n)}

        def mincap_restore(w: World) -> Optional[Action]:
            idx = w.pick_open()
            if idx is None: return None
            if w.headroom() >= self.adapter.cost(w, Action(ActionType.BUILD)):
                return Action(ActionType.BUILD, vessel_i=idx, tag="restore-build")
            return None

        return {
            "Liquidity Floor": {"test": liquidity_test, "restore": liquidity_restore, "packet": "floor_liquidity"},
            "Storehouse Floor": {"test": storehouse_test, "restore": storehouse_restore, "packet": "floor_storehouse"},
            "Min Capacity": {"test": mincap_test, "restore": mincap_restore, "packet": "floor_mincap"},
        }

    def _default_quarantine_rules(self) -> Dict[str, Dict[str, Any]]:
        primary = self.rules.primary_resource
        opf = float(self.rules.floors.get(primary, 0.0))

        def liquidity_gate(w: World, a: Action) -> Tuple[bool, Dict[str, Any]]:
            spend = self.adapter.cost(w, a)
            ok = (float(w.resources.get(primary, 0.0)) - spend) >= opf
            return ok, {"cash_ok": ok, "spend": spend, "opf": opf}

        def no_open_in_restore(w: World, a: Action) -> Tuple[bool, Dict[str, Any]]:
            ok = not (w.mode == Mode.RESTORE and a.k == ActionType.OPEN)
            return ok, {"open_ok": ok}

        def cap_gate(_w: World, _a: Action) -> Tuple[bool, Dict[str, Any]]:
            return True, {"cap_ok": True}

        return {
            "Liquidity Gate": {"test": liquidity_gate},
            "No Open In Restore": {"test": no_open_in_restore},
            "Capacity Gate": {"test": cap_gate},
        }

    # --------- Floors + mode ---------

    def determine_mode(self, w: World) -> List[Dict[str, Any]]:
        reports: List[Dict[str, Any]] = []
        failed = False
        for name, spec in self.rules.rules.items():
            ok, rep = spec["test"](w)
            reports.append({"name": name, "ok": ok, "report": rep})
            if not ok: failed = True
        w.mode = Mode.RESTORE if failed else Mode.NORMAL
        return reports

    # --------- Routing (on/off ramps) ---------

    def route(self, w: World) -> Tuple[str, Action, Optional[ScriptureSolution], List[Dict[str, Any]]]:
        # BOOTSTRAP ramp
        if len(w.vessels) < self.rules.INIT_VESSELS:
            return ROAD_BOOTSTRAP, Action(ActionType.OPEN, tag="bootstrap"), None, []

        floor_reports = self.determine_mode(w)
        sol: Optional[ScriptureSolution] = self.solver.solve(self.problem_seed, w) if self.solver and self.problem_seed else None

        # Scripture bias (does not bypass floors)
        directives = [d["rule"] for d in (sol.directives if sol else [])]

        # RESTORE ramp: data-driven priority stack (Action 4)
        if w.mode == Mode.RESTORE:
            # If Scripture explicitly says floor-first, we still restore but choose actions via priority list
            for rule_name in self.rules.rule_priority:
                if rule_name not in self.rules.rules:
                    continue
                ok, _ = self.rules.rules[rule_name]["test"](w)
                if ok:
                    continue
                act = self.rules.rules[rule_name]["restore"](w)
                if act:
                    return ROAD_RESTORE, act, sol, floor_reports
            return ROAD_RESTORE, Action(ActionType.HOLD, tag="restore-hold"), sol, floor_reports

        # NORMAL ramps
        idx = w.pick_open()
        build_cost = self.adapter.cost(w, Action(ActionType.BUILD))
        if idx is not None and w.headroom() >= build_cost:
            return ROAD_BUILD, Action(ActionType.BUILD, vessel_i=idx, tag="build"), sol, floor_reports

        hr = w.headroom()
        if hr > 0:
            # Scripture can bias toward FIRSTFRUITS
            if "FIRSTFRUITS" in directives and w.storehouse < self.rules.storehouse_floor:
                return ROAD_ALLOCATE, Action(ActionType.RESERVE, amt=hr * self.rules.FIRSTFRUIT_RATE, tag="firstfruits"), sol, floor_reports

            if w.storehouse < self.rules.storehouse_floor:
                return ROAD_ALLOCATE, Action(ActionType.RESERVE, amt=hr * self.rules.FIRSTFRUIT_RATE, tag="firstfruits"), sol, floor_reports
            return ROAD_ALLOCATE, Action(ActionType.INNOV, amt=hr * self.rules.INNOV_RATE, tag="innov"), sol, floor_reports

        return ROAD_HOLD, Action(ActionType.HOLD, tag="hold"), sol, floor_reports

    # --------- Quarantine/admission gate ---------

    def admit(self, w: World, a: Action) -> Dict[str, Any]:
        reports: List[Dict[str, Any]] = []
        passes = 0
        for name, spec in self.rules.quarantine.items():
            ok, rep = spec["test"](w, a)
            reports.append({"name": name, "ok": ok, "report": rep})
            if ok: passes += 1
        ok = passes >= int(self.rules.Q)
        if not ok:
            w.never_events += 1
        return {"ok": ok, "reports": reports, "passes": passes}

    # --------- Tick ---------

    def tick(self, w: World) -> None:
        shock = self.adapter.dynamics(w)
        road, action, sol, floor_reports = self.route(w)
        gate = self.admit(w, action)
        if gate["ok"]:
            self.adapter.apply(w, action)

        if self.ledger:
            payload: Dict[str, Any] = {
                "t": w.t,
                "role_handoff": {"decided_by": self.handoff.decided_by.name, "recorded_by": self.handoff.recorded_by.name, "executed_by": self.handoff.executed_by.name},
                "mode": w.mode.value,
                "road": road,
                "action": action.k.value,
                "tag": action.tag,
                "resources": dict(w.resources),
                "storehouse": w.storehouse,
                "tests_pool": w.tests_pool,
                "vessels": len(w.vessels),
                "cap_n": w.cap_n,
                "open_n": w.open_n,
                "units_total": w.units_total,
                "never_events": w.never_events,
                "floors": floor_reports,
                "gate_ok": gate["ok"],
                "gate_reports": gate["reports"],
                "shock": shock,
                "measures": self.adapter.measures(w),
            }
            if sol:
                payload["scripture_solution"] = {
                    "domains": sol.domains,
                    "anchors": [{"ref": a.ref, "principle": a.principle, "summary": a.summary} for a in sol.anchors],
                    "directives": sol.directives,
                }
            self.ledger.emit("tick_packet_v2", payload)

    def run(self, start_mult: float = 2.5) -> World:
        # initialize resources at a multiple of the floor for the primary resource
        primary = self.rules.primary_resource
        floor = float(self.rules.floors.get(primary, 0.0))
        w = World(rules=self.rules, adapter=self.adapter, resources={primary: floor * float(start_mult)})
        w.bootstrap_vessels(self.rules.INIT_VESSELS)
        for t in range(1, int(self.rules.Y) + 1):
            w.t = t
            self.tick(w)
        return w

# =========================
# Runner (econdev pressure test)
# =========================

def main():
    # Universal rules tuned for stability-first; growth comes after floors.
    rules = SeedRules(
        Y=40,
        rng=7,
        Q=2,
        INIT_VESSELS=3,
        SPAN=12,
        mincap=3,
        primary_resource="cash",
        floors={"cash": 2_000_000},
        storehouse_floor=5_000_000,
        FIRSTFRUIT_RATE=0.10,
        INNOV_RATE=0.10,
        rule_priority=["Liquidity Floor", "Min Capacity", "Storehouse Floor"],  # Action 4 (data-driven)
    )

    problem_seed = ProblemSeed(
        identity={"name": "NWGA Industrial Readiness", "translation_pack": "NIV"},
        phase="Setup",
        floors={"cash": rules.floors["cash"], "storehouse": rules.storehouse_floor, "mincap": rules.mincap},
        constraints={"span": rules.SPAN, "mincap": rules.mincap, "firstfruits": rules.FIRSTFRUIT_RATE, "innov": rules.INNOV_RATE},
    )

    adapter = EconDevAdapter(
        seed_in=2_000_000,
        cost_unit=750_000,
        surp_unit=120_000,
        shock_n=5,
        shock_i=0.3,
        fail=0.05,
        rng=rules.rng,
    )

    ledger = Ledger(kernel_version="PCK_problem_engine_v2_econdev")
    k = Kernel(rules=rules, adapter=adapter, problem_seed=problem_seed, ledger=ledger)
    final = k.run(start_mult=2.5)

    print("Final:")
    print("units_total:", final.units_total)
    print("vessels:", len(final.vessels))
    print("cash:", round(final.resources["cash"], 2))
    print("storehouse:", round(final.storehouse, 2))
    print("tests_pool:", round(final.tests_pool, 2))
    print("mature_vessels:", final.cap_n)
    print("never_events:", final.never_events)
    print("\nLedger JSONL (first 2 lines):")
    for ln in ledger.to_jsonl().splitlines()[:2]:
        print(ln)

if __name__ == "__main__":
    main()
