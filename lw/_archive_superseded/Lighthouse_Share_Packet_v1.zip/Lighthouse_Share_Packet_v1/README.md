# Lighthouse / Waymaker — Share Packet (Current State)

This is a snapshot of the current architecture + kernel + code for review and implementation.

## Start here
1) docs/CANON.md
2) docs/KERNEL.md
3) docs/LAYERS.md
4) code/pck_problem_engine_best.py

## What you’re looking at
A universal kernel that:
- ingests a problem seed
- routes actions via rules + gates
- logs append-only packets
- supports offline-first operation
- allows stewardship + witness + waiting for changes

## Included
- docs: canon + kernel + layers
- code: current engine files + keeper gate module
- data: econdev seed + schema registry
- inputs: original hardware/software zip references
