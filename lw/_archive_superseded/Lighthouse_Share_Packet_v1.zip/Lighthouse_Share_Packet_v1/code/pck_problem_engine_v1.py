
import json
import uuid
import hashlib
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional, Callable
from enum import Enum

# ============================================================
# PROBLEM ENGINE (Single-file, compressed)
# Universal Kernel + Adapter + ScriptureSolver (PolicyCompiler)
# NOTE: Scripture anchors store references + principles + brief summaries
# (Not full NIV verse text; keep translation packs external if needed.)
# ============================================================

# ----------------------------
# Schemas
# ----------------------------
class Mode(str, Enum):
    RESTORE = "RESTORE"
    NORMAL = "NORMAL"

class Status(str, Enum):
    OPEN = "OPEN"
    MATURE = "MATURE"

class Road(str, Enum):
    BOOTSTRAP = "BOOTSTRAP"
    RESTORE = "RESTORE"
    BUILD = "BUILD"
    ALLOCATE = "ALLOCATE"
    HOLD = "HOLD"

class ActionType(str, Enum):
    OPEN = "OPEN"
    BUILD = "BUILD"
    RESERVE = "RESERVE"
    INNOV = "INNOV"
    HOLD = "HOLD"

@dataclass(frozen=True)
class Action:
    k: ActionType
    vessel_i: Optional[int] = None
    amt: float = 0.0
    tag: str = ""

@dataclass(frozen=True)
class ProblemSeed:
    identity: Dict[str, Any] = field(default_factory=dict)     # e.g., {"name": "...", "translation_pack": "NIV"}
    phase: str = "Setup"                                      # "Setup|Positioning|Conversion"
    state: Dict[str, Any] = field(default_factory=dict)       # any domain state snapshot
    floors: Dict[str, float] = field(default_factory=dict)    # e.g., {"cash": 50_000_000, "storehouse": 150_000_000, "mincap": 3}
    constraints: Dict[str, Any] = field(default_factory=dict) # e.g., {"firstfruits_rate":0.1,"innov_rate":0.1,"span":12,"mincap":3}
    outcomes: Dict[str, Any] = field(default_factory=dict)    # lead/lag measures, etc.

@dataclass(frozen=True)
class ScriptureAnchor:
    ref: str
    principle: str
    summary: str  # brief paraphrase/summary (no full copyrighted text)

@dataclass(frozen=True)
class ScriptureSolution:
    anchors: List[ScriptureAnchor]
    directives: List[Dict[str, str]]  # e.g., [{"rule":"FLOOR_FIRST","meaning":"..."}]
    domains: List[str] = field(default_factory=list)

# ----------------------------
# Ledger
# ----------------------------
def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def uid() -> str:
    return str(uuid.uuid4())

@dataclass
class Ledger:
    kernel_version: str = "PCK_problem_engine_v1"
    events: List[Dict[str, Any]] = field(default_factory=list)

    def emit(self, packet_type: str, payload: Dict[str, Any]) -> None:
        pkt = {"packet_type": packet_type, "packet_id": uid(), "kernel_version": self.kernel_version, **payload}
        pkt["checksum"] = sha256_hex(canonical_json({k: v for k, v in pkt.items() if k != "checksum"}))
        self.events.append(pkt)

    def to_jsonl(self) -> str:
        return "\n".join(canonical_json(e) for e in self.events)

# ----------------------------
# Roles
# ----------------------------
@dataclass(frozen=True)
class Role:
    name: str

GUIDE = Role("Guide")
SCRIBE = Role("Scribe")
STEWARD = Role("Steward")

@dataclass(frozen=True)
class RoleHandoff:
    decided_by: Role = GUIDE
    recorded_by: Role = SCRIBE
    executed_by: Role = STEWARD
    note: Optional[str] = None

# ----------------------------
# Rules (first-class)
# ----------------------------
@dataclass
class Rule:
    name: str
    tests: Callable[['World'], Tuple[bool, Dict[str, bool]]]
    restoration_action: Callable[['World'], Optional[Action]]
    packet_type: str = "rule_report_v1"

@dataclass(frozen=True)
class SeedRules:
    Y: int = 40
    rng: int = 7

    # Admission (quarantine) threshold: pass at least Q tests
    Q: int = 2

    # Structure
    INIT_VESSELS: int = 3
    SPAN: int = 12               # maturity threshold per vessel
    mincap: int = 3              # minimum # mature vessels

    # Resource naming (universal)
    primary_resource: str = "cash"

    # Floors (universal)
    floors: Dict[str, float] = field(default_factory=lambda: {"cash": 2_000_000})
    storehouse_floor: float = 5_000_000

    # Allocations (universal)
    FIRSTFRUIT_RATE: float = 0.10
    INNOV_RATE: float = 0.10

    # Rule registries
    rules: List[Rule] = field(default_factory=list)
    quarantine_rules: List[Rule] = field(default_factory=list)

def get_default_rules(seed: SeedRules) -> List[Rule]:
    def liquidity_ok(w: 'World') -> bool:
        return w.resources.get(seed.primary_resource, 0.0) >= seed.floors.get(seed.primary_resource, 0.0)

    def storehouse_ok(w: 'World') -> bool:
        return w.storehouse >= seed.storehouse_floor

    def mincap_ok(w: 'World') -> bool:
        return w.cap_n >= seed.mincap

    return [
        Rule(
            name="Liquidity Floor",
            tests=lambda w: (liquidity_ok(w), {"liquidity_ok": liquidity_ok(w)}),
            restoration_action=lambda w: None,
            packet_type="liquidity_report_v1",
        ),
        Rule(
            name="Storehouse Floor",
            tests=lambda w: (storehouse_ok(w), {"storehouse_ok": storehouse_ok(w)}),
            restoration_action=lambda w: Action(ActionType.RESERVE, amt=min(500_000, w.headroom()), tag="restore-storehouse")
                                      if w.headroom() > 0 else None,
            packet_type="storehouse_report_v1",
        ),
        Rule(
            name="Min Capacity",
            tests=lambda w: (mincap_ok(w), {"mincap_ok": mincap_ok(w)}),
            restoration_action=lambda w: Action(ActionType.BUILD, vessel_i=w.pick_open(), tag="restore-build")
                                      if (w.pick_open() is not None and w.headroom() >= w.adapter.cost(w, Action(ActionType.BUILD))) else None,
            packet_type="capacity_report_v1",
        ),
    ]

def get_default_quarantine_rules(seed: SeedRules) -> List[Rule]:
    # Each rule returns (pass/fail, report dict). Kernel admits if >= Q pass.
    return [
        Rule(
            name="Liquidity Gate",
            tests=lambda w: (
                (w.resources.get(seed.primary_resource, 0.0) - w.adapter.cost(w, w._pending_action)) >= seed.floors.get(seed.primary_resource, 0.0),
                {"cash_ok": (w.resources.get(seed.primary_resource, 0.0) - w.adapter.cost(w, w._pending_action)) >= seed.floors.get(seed.primary_resource, 0.0)},
            ),
            restoration_action=lambda w: None,
            packet_type="gate_liquidity_v1",
        ),
        Rule(
            name="No Open in Restore",
            tests=lambda w: (
                not (w.mode == Mode.RESTORE and w._pending_action.k == ActionType.OPEN),
                {"open_ok": not (w.mode == Mode.RESTORE and w._pending_action.k == ActionType.OPEN)},
            ),
            restoration_action=lambda w: None,
            packet_type="gate_no_open_restore_v1",
        ),
        Rule(
            name="Capacity Cap",
            tests=lambda w: (True, {"cap_ok": True}),
            restoration_action=lambda w: None,
            packet_type="gate_cap_ok_v1",
        ),
    ]

# ----------------------------
# ScriptureSolver (PolicyCompiler)
# ----------------------------
class ScriptureSolver:
    """
    Produces ScriptureSolution:
      - domains: 1–3 active lenses
      - anchors: ref + principle + short summary
      - directives: universal rule tokens mapping to kernel primitives (roads/actions/rules)
    """
    def __init__(self, translation_pack: str = "NIV"):
        self.translation_pack = translation_pack

        # Keep small. Add more domains later without changing kernel nouns.
        self.domains: Dict[str, Dict[str, Any]] = {
            "Stability / Foundation": {
                "anchors": [
                    ScriptureAnchor("Proverbs 4:23", "Guard inputs; control gates",
                                    "Prioritize guarding the core; what you allow in shapes outcomes."),
                ],
                "directives": [
                    {"rule": "FLOOR_FIRST", "meaning": "Stability before expansion"},
                    {"rule": "QUARANTINE_UNKNOWN", "meaning": "Admit only validated work"},
                ],
            },
            "Governance / Delegation": {
                "anchors": [
                    ScriptureAnchor("Exodus 18:17–23", "Delegation / span of care",
                                    "Distribute load through trusted leaders; structure prevents burnout."),
                ],
                "directives": [
                    {"rule": "SPAN_LIMIT", "meaning": "No vessel exceeds span-of-care"},
                ],
            },
            "Provision / Storehouse": {
                "anchors": [
                    ScriptureAnchor("Genesis 41:34–36", "Storehouse reserves",
                                    "Use abundance to build reserves for lean seasons."),
                ],
                "directives": [
                    {"rule": "FIRSTFRUITS", "meaning": "Reserve allocation (storehouse) is required"},
                ],
            },
            "Growth / Fruit / Pruning": {
                "anchors": [
                    ScriptureAnchor("John 15:2", "Prune for fruit",
                                    "Remove what is unfruitful; refine what is fruitful."),
                ],
                "directives": [
                    {"rule": "PRUNE", "meaning": "Remove fruitless branches when needed"},
                ],
            },
        }

    def classify_domains(self, seed: ProblemSeed, w: 'World') -> List[str]:
        """
        1–3 domains, chosen by phase + floor breaches + signals.
        Keep it simple and predictable.
        """
        out: List[str] = []

        # Always include Stability lens when restoring
        if w.mode == Mode.RESTORE:
            out.append("Stability / Foundation")

        # Setup phase tends to emphasize provisioning + foundations
        if seed.phase.lower() == "setup":
            if "Provision / Storehouse" not in out:
                out.append("Provision / Storehouse")

        # If storehouse below scenario floor (if provided), emphasize Provision
        scenario_store_floor = float(seed.floors.get("storehouse", 0.0) or 0.0)
        if scenario_store_floor > 0 and w.storehouse < scenario_store_floor:
            if "Provision / Storehouse" not in out:
                out.append("Provision / Storehouse")

        # If below mincap floor, emphasize Governance/Delegation
        scenario_mincap = int(seed.floors.get("mincap", seed.constraints.get("mincap", 0) or 0) or 0)
        if scenario_mincap > 0 and w.cap_n < scenario_mincap:
            if "Governance / Delegation" not in out:
                out.append("Governance / Delegation")

        # If repeated blocks, bring Pruning lens
        if w.never_events >= 3 and "Growth / Fruit / Pruning" not in out:
            out.append("Growth / Fruit / Pruning")

        return out[:3]

    def solve(self, seed: ProblemSeed, w: 'World') -> ScriptureSolution:
        domains = self.classify_domains(seed, w)
        anchors: List[ScriptureAnchor] = []
        directives: List[Dict[str, str]] = []
        for d in domains:
            cfg = self.domains.get(d)
            if not cfg:
                continue
            anchors.extend(cfg["anchors"])
            directives.extend(cfg["directives"])
        return ScriptureSolution(anchors=anchors, directives=directives, domains=domains)

# ----------------------------
# Adapter (domain mapping)
# ----------------------------
class Adapter:
    def cost(self, w: 'World', a: Action) -> float:
        raise NotImplementedError

    def dynamics(self, w: 'World') -> Dict[str, Any]:
        raise NotImplementedError

    def apply(self, w: 'World', a: Action) -> None:
        raise NotImplementedError

    def measures(self, w: 'World') -> Dict[str, Any]:
        raise NotImplementedError

class EconDevAdapter(Adapter):
    """
    Pressure-test adapter: maps econdev to universal grammar.
    Uses primary_resource "cash" by default.
    """
    def __init__(self, seed_in: float, cost_unit: float, surp_unit: float, shock_n: int, shock_i: float, fail: float, rng: int, primary_resource: str = "cash"):
        self.SEED_IN = float(seed_in)
        self.COST = float(cost_unit)
        self.SURP = float(surp_unit)
        self.SHOCKN = int(shock_n)
        self.SHOCKI = float(shock_i)
        self.FAIL = float(fail)
        self.primary = primary_resource
        self.rng = random.Random(rng)

    def cost(self, w: 'World', a: Action) -> float:
        if a.k == ActionType.BUILD:
            return self.COST
        if a.k in (ActionType.RESERVE, ActionType.INNOV):
            return float(a.amt)
        return 0.0

    def dynamics(self, w: 'World') -> Dict[str, Any]:
        shock_in = (self.rng.random() < 1 / max(1, self.SHOCKN))
        shock_sur = (self.rng.random() < 1 / max(1, self.SHOCKN))

        inflow = self.SEED_IN * (1 - self.SHOCKI) if shock_in else self.SEED_IN
        w.resources[self.primary] = w.resources.get(self.primary, 0.0) + inflow

        surplus = w.units_total * self.SURP
        surplus *= (1 - self.SHOCKI) if shock_sur else 1.0
        w.resources[self.primary] += surplus

        pruned = False
        before = len(w.vessels)
        if self.FAIL > 0 and w.vessels:
            w.vessels = [v for v in w.vessels if self.rng.random() > self.FAIL]
            if not w.vessels:
                w.bootstrap_vessels(1)
            pruned = (len(w.vessels) != before)

        return {"shock_inflow": shock_in, "shock_surplus": shock_sur, "inflow": inflow, "surplus": surplus, "pruned": pruned,
                "vessels_before": before, "vessels_after": len(w.vessels)}

    def apply(self, w: 'World', a: Action) -> None:
        if a.k == ActionType.OPEN:
            w.open_vessel()
        elif a.k == ActionType.BUILD and a.vessel_i is not None:
            w.build_unit(a.vessel_i)
            w.resources[self.primary] -= self.COST
        elif a.k == ActionType.RESERVE:
            x = min(float(a.amt), w.headroom())
            w.resources[self.primary] -= x
            w.storehouse += x
        elif a.k == ActionType.INNOV:
            x = min(float(a.amt), w.headroom())
            w.resources[self.primary] -= x
            w.tests_pool += x
        # HOLD no-op

    def measures(self, w: 'World') -> Dict[str, Any]:
        return {"units_total": w.units_total, "vessels": len(w.vessels), "cap_n": w.cap_n, "open_n": w.open_n}

# ----------------------------
# World / Vessel (universal)
# ----------------------------
@dataclass
class Vessel:
    id: int
    units: int = 0
    status: Status = Status.OPEN

    def update(self, span: int) -> None:
        if self.status == Status.OPEN and self.units >= span:
            self.status = Status.MATURE

@dataclass
class World:
    rules: SeedRules
    adapter: Adapter
    resources: Dict[str, float] = field(default_factory=dict)
    storehouse: float = 0.0
    tests_pool: float = 0.0
    vessels: List[Vessel] = field(default_factory=list)

    mode: Mode = Mode.RESTORE
    t: int = 0
    never_events: int = 0

    # internal: used only during admit()
    _pending_action: Action = field(default_factory=lambda: Action(ActionType.HOLD), repr=False)

    @property
    def units_total(self) -> int:
        return sum(v.units for v in self.vessels)

    @property
    def cap_n(self) -> int:
        return sum(1 for v in self.vessels if v.status == Status.MATURE)

    @property
    def open_n(self) -> int:
        return sum(1 for v in self.vessels if v.status == Status.OPEN)

    def headroom(self) -> float:
        pr = self.rules.primary_resource
        return max(0.0, self.resources.get(pr, 0.0) - self.rules.floors.get(pr, 0.0))

    def bootstrap_vessels(self, n: int) -> None:
        start = len(self.vessels)
        for i in range(n):
            self.vessels.append(Vessel(id=start + i + 1))

    def open_vessel(self) -> None:
        self.vessels.append(Vessel(id=len(self.vessels) + 1))

    def build_unit(self, vessel_i: int) -> None:
        if vessel_i < 0 or vessel_i >= len(self.vessels):
            return
        v = self.vessels[vessel_i]
        v.units += 1
        v.update(self.rules.SPAN)

    def pick_open(self) -> Optional[int]:
        candidates = [(i, v.units) for i, v in enumerate(self.vessels) if v.status == Status.OPEN]
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0] if candidates else None

# ----------------------------
# Kernel (universal)
# ----------------------------
class Kernel:
    def __init__(self, rules: SeedRules, adapter: Adapter, problem_seed: Optional[ProblemSeed] = None,
                 ledger: Optional[Ledger] = None, handoff: Optional[RoleHandoff] = None):
        self.rules = rules
        self.adapter = adapter
        self.problem_seed = problem_seed
        self.scripture_solver = ScriptureSolver(problem_seed.identity.get("translation_pack", "NIV")) if problem_seed else None
        self.ledger = ledger
        self.handoff = handoff or RoleHandoff()

        if not self.rules.rules:
            object.__setattr__(self.rules, "rules", get_default_rules(self.rules))
        if not self.rules.quarantine_rules:
            object.__setattr__(self.rules, "quarantine_rules", get_default_quarantine_rules(self.rules))

    def determine_mode(self, w: World) -> List[Dict[str, Any]]:
        reports: List[Dict[str, Any]] = []
        failed = False
        for rule in self.rules.rules:
            ok, report = rule.tests(w)
            reports.append({"name": rule.name, "ok": ok, "report": report, "packet_type": rule.packet_type})
            if not ok:
                failed = True
        w.mode = Mode.RESTORE if failed else Mode.NORMAL
        return reports

    def compile_scripture(self, w: World) -> Optional[ScriptureSolution]:
        if not self.scripture_solver or not self.problem_seed:
            return None
        return self.scripture_solver.solve(self.problem_seed, w)



    def route(self, w: World) -> Tuple[Road, Action, Optional[ScriptureSolution], List[Dict[str, Any]]]:
        # 1) BOOTSTRAP
        if len(w.vessels) < self.rules.INIT_VESSELS:
            return Road.BOOTSTRAP, Action(ActionType.OPEN, tag="bootstrap"), None, []

        # 2) Determine mode (floors) first
        mode_reports = self.determine_mode(w)

        # 3) Compile scripture (policy) for auditing + optional bias
        scripture_solution = self.compile_scripture(w)

        # 4) RESTORE: choose among failed-floor restorations using a priority stack
        # Priority (stability-first but not "stuck"):
        #   A) liquidity floor (can't act without it)
        #   B) min-capacity restoration (build formation) if feasible
        #   C) storehouse (reserve) to rebuild buffer
        if w.mode == Mode.RESTORE:
            failed = {r["name"]: r for r in mode_reports if not r["ok"]}

            # Build a map from rule name -> restoration action (if any)
            actions: Dict[str, Action] = {}
            for rep in failed.values():
                rule = next(rr for rr in self.rules.rules if rr.name == rep["name"])
                a = rule.restoration_action(w)
                if a:
                    actions[rep["name"]] = a

            # A) Liquidity Floor must be OK (usually has no action here)
            if "Liquidity Floor" in failed and "Liquidity Floor" in actions:
                return Road.RESTORE, actions["Liquidity Floor"], scripture_solution, mode_reports

            # B0) Storehouse balancing: while restoring formation, still feed the storehouse on a cadence
            if "Storehouse Floor" in failed and w.headroom() > 0:
                # 10% pressure cadence: every 3rd unit build, feed storehouse; also feed once you have at least 1 mature vessel
                if (w.cap_n >= 1) or (w.units_total > 0 and w.units_total % 3 == 0):
                    a = actions.get("Storehouse Floor")
                    if a:
                        return Road.RESTORE, a, scripture_solution, mode_reports

            # B) Min Capacity: if feasible, build to escape permanent reserve-loop
            if "Min Capacity" in failed and "Min Capacity" in actions:
                return Road.RESTORE, actions["Min Capacity"], scripture_solution, mode_reports

            # C) Storehouse: reserve to rebuild buffer
            if "Storehouse Floor" in failed and "Storehouse Floor" in actions:
                return Road.RESTORE, actions["Storehouse Floor"], scripture_solution, mode_reports

            # If scripture emphasizes FLOOR_FIRST, hold steady
            if scripture_solution and any(d.get("rule") == "FLOOR_FIRST" for d in scripture_solution.directives):
                return Road.RESTORE, Action(ActionType.HOLD, tag="floor_first"), scripture_solution, mode_reports

            return Road.RESTORE, Action(ActionType.HOLD, tag="restore-hold"), scripture_solution, mode_reports

        # 5) NORMAL mode: if storehouse below floor, allocate FIRSTFRUITS
        if w.headroom() > 0 and w.storehouse < self.rules.storehouse_floor:
            return Road.ALLOCATE, Action(
                ActionType.RESERVE,
                amt=w.headroom() * self.rules.FIRSTFRUIT_RATE,
                tag="firstfruits",
            ), scripture_solution, mode_reports

        # 6) BUILD if possible while respecting floors
        idx = w.pick_open()
        build_cost = self.adapter.cost(w, Action(ActionType.BUILD))
        if idx is not None and w.headroom() >= build_cost:
            return Road.BUILD, Action(ActionType.BUILD, vessel_i=idx, tag="build"), scripture_solution, mode_reports

        # 7) ALLOCATE: innovation pool (10% pressure)
        if w.headroom() > 0:
            return Road.ALLOCATE, Action(
                ActionType.INNOV,
                amt=w.headroom() * self.rules.INNOV_RATE,
                tag="innov",
            ), scripture_solution, mode_reports

        # 8) HOLD
        if scripture_solution and any(d.get("rule") == "PRUNE" for d in scripture_solution.directives) and w.never_events >= 3:
            return Road.HOLD, Action(ActionType.HOLD, tag="prune-hold"), scripture_solution, mode_reports

        return Road.HOLD, Action(ActionType.HOLD, tag="hold"), scripture_solution, mode_reports



    def admit(self, w: World, a: Action) -> Dict[str, Any]:
        w._pending_action = a
        reports = []
        passes = 0
        for rule in self.rules.quarantine_rules:
            ok, report = rule.tests(w)
            reports.append({"name": rule.name, "ok": ok, "report": report, "packet_type": rule.packet_type})
            if ok:
                passes += 1
        ok = passes >= self.rules.Q
        if not ok:
            w.never_events += 1
        w._pending_action = Action(ActionType.HOLD)
        return {"ok": ok, "reports": reports, "passes": passes, "needed": self.rules.Q}

    def tick(self, w: World) -> None:
        shock_info = self.adapter.dynamics(w)
        road, action, scripture_solution, mode_reports = self.route(w)
        gate = self.admit(w, action)
        if gate["ok"]:
            self.adapter.apply(w, action)

        if self.ledger:
            payload = {
                "t": w.t,
                "role_handoff": {
                    "decided_by": self.handoff.decided_by.name,
                    "recorded_by": self.handoff.recorded_by.name,
                    "executed_by": self.handoff.executed_by.name,
                },
                "mode": w.mode.value,
                "road": road.value,
                "action": action.k.value,
                "tag": action.tag,
                "resources": dict(w.resources),
                "storehouse": w.storehouse,
                "tests_pool": w.tests_pool,
                "vessels": len(w.vessels),
                "cap_n": w.cap_n,
                "open_n": w.open_n,
                "units_total": w.units_total,
                "never_events": w.never_events,
                "gate_ok": gate["ok"],
                "gate_meta": {"passes": gate["passes"], "needed": gate["needed"]},
                "gate_reports": gate["reports"],
                "mode_reports": mode_reports,
                "shock": shock_info,
                "measures": self.adapter.measures(w),
            }
            if scripture_solution:
                payload["scripture_solution"] = {
                    "domains": scripture_solution.domains,
                    "anchors": [{"ref": a.ref, "principle": a.principle, "summary": a.summary} for a in scripture_solution.anchors],
                    "directives": scripture_solution.directives,
                }
            self.ledger.emit("tick_packet_v1", payload)

    def run(self, start_mult: float = 2.5) -> World:
        w = World(rules=self.rules, adapter=self.adapter)
        pr = self.rules.primary_resource
        base = self.rules.floors.get(pr, 0.0)
        w.resources[pr] = base * start_mult
        w.bootstrap_vessels(self.rules.INIT_VESSELS)

        for t in range(1, self.rules.Y + 1):
            w.t = t
            self.tick(w)
        return w

# ----------------------------
# Example Runner (econdev pressure test)
# ----------------------------
def main():
    # ProblemSeed defines scenario floors/constraints (pressure parameters)
    problem_seed = ProblemSeed(
        identity={"name": "NWGA Industrial Readiness", "translation_pack": "NIV"},
        phase="Setup",
        floors={"cash": 50_000_000, "storehouse": 150_000_000, "mincap": 3},
        constraints={"firstfruits_rate": 0.10, "innov_rate": 0.10, "span": 12, "mincap": 3},
    )

    # SeedRules: kernel-side parameters (can be derived from ProblemSeed)
    rules = SeedRules(
        Y=40,
        rng=7,
        Q=2,
        INIT_VESSELS=3,
        SPAN=int(problem_seed.constraints.get("span", 12)),
        mincap=int(problem_seed.constraints.get("mincap", 3)),
        primary_resource="cash",
        floors={"cash": float(problem_seed.floors.get("cash", 2_000_000))},
        storehouse_floor=float(problem_seed.floors.get("storehouse", 5_000_000)),
        FIRSTFRUIT_RATE=float(problem_seed.constraints.get("firstfruits_rate", 0.10)),
        INNOV_RATE=float(problem_seed.constraints.get("innov_rate", 0.10)),
    )

    adapter = EconDevAdapter(
        seed_in=2_000_000,
        cost_unit=750_000,
        surp_unit=120_000,
        shock_n=5,
        shock_i=0.3,
        fail=0.05,
        rng=rules.rng,
        primary_resource=rules.primary_resource,
    )

    ledger = Ledger(kernel_version="PCK_problem_engine_v1_econdev")
    k = Kernel(rules=rules, adapter=adapter, problem_seed=problem_seed, ledger=ledger)

    final = k.run(start_mult=1.05)  # start near floor for pressure

    print("Final:")
    print("units_total:", final.units_total)
    print("vessels:", len(final.vessels))
    print("cash:", round(final.resources["cash"], 2))
    print("storehouse:", round(final.storehouse, 2))
    print("tests_pool:", round(final.tests_pool, 2))
    print("mature_vessels:", final.cap_n)
    print("never_events:", final.never_events)

    # show a few scripture-influenced ticks
    print("\nSample ticks with scripture_solution (first 3 that include it):")
    shown = 0
    for e in ledger.events:
        ss = e.get("scripture_solution")
        if ss:
            print("t", e["t"], "mode", e["mode"], "road", e["road"], "action", e["action"], "domains", ss["domains"])
            shown += 1
            if shown >= 3:
                break

if __name__ == "__main__":
    main()
