"""
PCK / Waymaker — Physical Firewall Plane (Steward MCU Spec Pack)
Drop-in "gate pack" + state machine reference that integrates with pck_problem_engine_best.py
WITHOUT changing the kernel verbs (O/B/R/H).

What this file provides:
  - FirewallState: models the physical firewall behavior (intent, timers, budgets)
  - Gate builders: produce Gate definitions compatible with the engine (GDef)
  - Minimal "mail-slot" ledger valve protocol (propose -> verify -> commit) as stubs

Hardware intent:
  - Steward MCU is the final authority for: WIFI_EN, USB_DATA_EN, LORA_TX_WIN, SOC_WAKE, LEDGER_COMMIT
  - Defaults: closed (wifi off, usb data off), LoRa nano only, ledger append-only
  - On-ramps: physical intent opens timed windows
  - Off-ramps: timer expiry, floor threat, gate breach -> close + (optionally) SAFE_SHUTDOWN

This is a SPEC in executable form (simulation). Real firmware would implement the same state machine.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Callable
import time

# Import types from the best engine (keep names stable).
# If you rename the engine file, update this import.
from pck_problem_engine_best import A, Act, GDef, World

# --------------------------
# Firewall / Steward State
# --------------------------

@dataclass
class FirewallState:
    # Physical intent signals (modeled here as booleans/events)
    wifi_intent: bool = False      # e.g., physical button / NFC intent
    usb_intent: bool = False       # e.g., plug + known device + physical confirm

    # Timed windows (seconds since epoch). If now > until => closed.
    wifi_until: float = 0.0
    usb_until: float = 0.0

    # Byte budgets (LEAN enforcement)
    # nano = LoRa allowed; meso = gated online lane; bulk = only when docked (USB mass storage)
    nano_max_b: int = 1024               # 1 KB typical; tune per radio
    meso_max_b: int = 64 * 1024          # 64 KB per session/window
    bulk_max_b: int = 1024 * 1024 * 1024 # 1 GB when physically docked

    # Counters for current window/session
    nano_sent_b: int = 0
    meso_sent_b: int = 0
    bulk_sent_b: int = 0

    # Safety state
    safe_shutdown: bool = False
    last_close_reason: str = ""

    def now(self) -> float:
        return time.time()

    def wifi_open(self) -> bool:
        return self.wifi_until > self.now()

    def usb_open(self) -> bool:
        return self.usb_until > self.now()

    def open_wifi(self, secs: int = 300) -> None:
        self.wifi_intent = True
        self.wifi_until = self.now() + secs

    def open_usb(self, secs: int = 300) -> None:
        self.usb_intent = True
        self.usb_until = self.now() + secs

    def close_all(self, reason: str) -> None:
        self.wifi_intent = False
        self.usb_intent = False
        self.wifi_until = 0.0
        self.usb_until = 0.0
        self.last_close_reason = reason

    def tick(self) -> None:
        # Auto-close expired windows
        if self.wifi_until and self.now() > self.wifi_until:
            self.wifi_intent = False
            self.wifi_until = 0.0
        if self.usb_until and self.now() > self.usb_until:
            self.usb_intent = False
            self.usb_until = 0.0

    # LEAN counters (these would be maintained by MCU in real life)
    def record_send(self, lane: str, nbytes: int) -> None:
        if lane == "nano":
            self.nano_sent_b += nbytes
        elif lane == "meso":
            self.meso_sent_b += nbytes
        elif lane == "bulk":
            self.bulk_sent_b += nbytes

    def budget_ok(self, lane: str, nbytes: int) -> bool:
        if lane == "nano":
            return (self.nano_sent_b + nbytes) <= self.nano_max_b
        if lane == "meso":
            return (self.meso_sent_b + nbytes) <= self.meso_max_b
        if lane == "bulk":
            return (self.bulk_sent_b + nbytes) <= self.bulk_max_b
        return False

# --------------------------
# Mail-slot (Ledger Valve) Stubs
# --------------------------

@dataclass
class MailSlot:
    """
    Journal <-> SoC valve protocol (conceptual).
    In hardware: SoC cannot write ledger storage directly.
    It can only PROPOSE packets into a mailbox; Journal verifies & commits.

    This is where "physical firewall between planes" becomes real at the data layer.
    """
    proposed: List[Dict[str, Any]] = field(default_factory=list)
    committed: List[Dict[str, Any]] = field(default_factory=list)

    def propose(self, pkt: Dict[str, Any]) -> None:
        self.proposed.append(pkt)

    def verify(self, pkt: Dict[str, Any]) -> bool:
        # Stub: plug in checksum / schema registry verification here.
        return True

    def commit(self) -> int:
        n = 0
        keep = []
        for pkt in self.proposed:
            if self.verify(pkt):
                self.committed.append(pkt)
                n += 1
            else:
                keep.append(pkt)
        self.proposed = keep
        return n

# --------------------------
# Gate Pack Builders
# --------------------------

def build_firewall_gates(
    fw: FirewallState,
    *,
    require_physical_intent_for_online: bool = True,
    lora_nano_only: bool = True,
    floor_close_on_breach: bool = True,
) -> List[GDef]:
    """
    Returns GDef gates compatible with the kernel's quarantine mechanism.
    These gates do NOT add new actions. They only allow/deny.

    Conventions:
      - World.rs contains primary resource floor logic already.
      - We attach desired metadata to Act.t (tag) when simulating network lanes.
        e.g., tag contains "lane:nano", "lane:meso", "lane:bulk".
    """

    def _lane_from_act(a: Act) -> str:
        # You can make this stricter later (explicit fields). For now, minimal tag parsing.
        t = (a.t or "")
        if "lane:nano" in t: return "nano"
        if "lane:meso" in t: return "meso"
        if "lane:bulk" in t: return "bulk"
        return "nano"  # default safest

    def g_windows(w: World, a: Act) -> Dict[str, bool]:
        """
        Enforce that any 'online' lane (meso/bulk) requires an open window.
        Nano is always allowed (LoRa) but budget-limited by g_budget.
        """
        fw.tick()
        lane = _lane_from_act(a)

        if not require_physical_intent_for_online:
            return {"WIN": True}

        if lane == "nano":
            return {"WIN": True}  # nano allowed even if windows closed
        if lane == "meso":
            return {"WIN": fw.usb_open() or fw.wifi_open()}
        if lane == "bulk":
            # bulk should require USB window (or explicit dock), modeled here as usb_open
            return {"WIN": fw.usb_open()}
        return {"WIN": False}

    def g_budget(w: World, a: Act) -> Dict[str, bool]:
        """
        LEAN enforcement: allow only if budget is available for the lane.
        """
        lane = _lane_from_act(a)
        # For simulation, approximate bytes per action (tunable).
        # In real system, the packet size is known before send.
        approx = 256 if lane == "nano" else 8192 if lane == "meso" else 1_000_000
        ok = fw.budget_ok(lane, approx)
        if ok:
            fw.record_send(lane, approx)
        return {"BUD": ok}

    def g_no_radio_open_in_restore(w: World, a: Act) -> Dict[str, bool]:
        """
        When the kernel is in RESTORE mode, block actions tagged as meso/bulk.
        This mirrors: radios off in restore; only nano alerts allowed.
        """
        lane = _lane_from_act(a)
        if w.m.value == "R" and lane in ("meso", "bulk"):
            return {"NOR": False}
        return {"NOR": True}

    def g_floor_close(w: World, a: Act) -> Dict[str, bool]:
        """
        If floors are threatened, close all windows (fail-safe).
        This is a gate side-effect. It can be disabled.
        """
        if not floor_close_on_breach:
            return {"CLS": True}
        # If primary cash is below floor (or close), close.
        pr = w.ru.pr
        if w.rs.get(pr, 0.0) < w.ru.fl.get(pr, 0.0):
            fw.close_all("floor_breach")
            return {"CLS": True}
        return {"CLS": True}

    gates = [
        GDef("FW_WIN", g_windows),
        GDef("FW_BUD", g_budget),
    ]
    if lora_nano_only:
        gates.append(GDef("FW_NOR", g_no_radio_open_in_restore))
    gates.append(GDef("FW_CLS", g_floor_close))
    return gates

# --------------------------
# Integration helper
# --------------------------

def install_firewall_pack(world: World, fw: FirewallState) -> None:
    """
    Call after creating Kernel+World:
      world.ru.g.extend(build_firewall_gates(fw))
    Keep the kernel unchanged; we're just adding gates.
    """
    world.ru.g.extend(build_firewall_gates(fw))

