# Camel Mode State Machine

States:
1. Camel (default)
2. Awake (interactive)
3. Windowed Connect
4. Shutdown / Preservation

All software workflows must declare valid states.
