# Lighthouse / Waymaker — Project Share Packet (v2)

**Date:** 2026-01-09  
**Goal:** Share the whole project efficiently with technical + non-technical collaborators.

This packet has two “front doors”:

1) **CODE (Engineer door):** `code/the_way_kernel_min.py` + `code/pck_problem_engine_best.py`  
2) **TEXT (Resonant door):** `docs/00_the_way_primer.md` (1 page) + `docs/01_fractal_playbook.md`

## What this project is
A **universal problem engine** that:
- receives a problem (parameters + context),
- routes it through a **Biblical Alignment Protocol** (Red → Floor → Brothers → God),
- produces a constrained action,
- records a **Playbook entry** (church-as-memory): confession → action → outcome → pruning.

## Core invariants (do not drift)
- **Canon is closed.** Playbook is testimony, not doctrine.
- **Red has priority.** Law is the floor. The Way is optimal.
- **Four gates:** Red, Floor, Brothers (witness), God (waiting).
- **Minimal actions:** OPEN, BUILD, RESERVE, PRUNE, HOLD.
- **Offline-first + efficient:** works without data centers; sync is optional.

## Folder map
- `docs/` — human-readable charter + playbook + diagrams (markdown)
- `code/` — reference implementations (python)
- `data/` — econdev seed + schema registry + harness stubs
- `hardware/` — Node/Vessel hardware playbooks (zips)

## Quick start (engineers)
```bash
python code/the_way_kernel_min.py
python code/pck_problem_engine_best.py
```

## Quick start (non-technical)
Open:
- `docs/00_the_way_primer.md`
- `docs/01_fractal_playbook.md`

---
