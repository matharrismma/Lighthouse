# Fractal Role Mapping

Main: SoC — decisions and interaction
Support: On-SoC services — capture, hygiene
Engine: Steward MCU — enforcement and truth

Lower layers cannot be overridden by upper layers.
