# Node Hardware Playbook v2 (Canonical)

This version installs the cohesive language operating system across all Node hardware documentation.

Key properties:
- Single Node SKU
- Fractal architecture: Main (SoC) / Support (Services) / Engine (Steward MCU)
- Steward is final authority
- Camel Mode is the default state machine
- Physical truth > software truth
