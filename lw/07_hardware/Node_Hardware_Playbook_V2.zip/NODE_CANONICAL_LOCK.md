# Canonical Lock — Node v2

These constraints override all other documents.

- ONE Node SKU
- Hybrid SoC + Steward MCU
- Camel Mode default
- Steward enforces power, radios, wake/sleep
- USB-C and microSD are trust roots
- NFC is intent signal
